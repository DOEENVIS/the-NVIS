This suite of tools are Beta v1.0 
Developed on python 2.7; ArcGIS 10.2

ERIN, Department of the Environment and Energy
John Gorton Building King Edward Terrace 
Parks ACT 2600 

------------------------------------------------------


Included in the NVIS Uncertainty Tools package are: 

    �	ArcGIS Uncertainty toolbox - with individual tools for age, origin, spatial mix and scale
    �	Python scripts - the raw scripts for the above tools, so a user may change any variable or function if they desire


This tool package has been provided to allow transparency, and for users to develop their own uncertainty layers at different weights or cell sizes. 


The 'Output' files from these tools/scripts are raster files, scaled 0-1, that can be used to include uncertainty into the use of NVIS data. These include:

      -	  Age: age of the NVIS data
      -	  Origin: where the data came from
      -	  Spatial mix: if the data is a mosaic
      -	  Scale: scale at which the data was mapped

Layers can be added/averaged together to form one uncertainty layer or output individually. 


These output files are also available as raster downloads and PDF maps from the 'NVIS data products' page on our website.

Review the metadata for more information.


