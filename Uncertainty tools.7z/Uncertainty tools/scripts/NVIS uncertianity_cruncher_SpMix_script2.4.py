"""
# Author: Jeremy Groves
# Date: August 31, 2015
# Purpose: produces a spatial mix uncertianity layer for NVIS. 

This suit of scripts have been developed in ERIN (Dept of the Environment) to create raster uncertainty layers that are intended to better describe the input datasets and assist in dynamic analyses of data quality and gaps in the NVIS extant theme dataset.
This specific script is to create the Scale Uncertainty raster layers. The inputs are 
NVIS4_1_......_EXT (all vector data); placed into the .gdb
"""

import arcpy
#sourcefc = r'N:\Veg\Tools\NVIS_util\Uncertainty\sourceSPmix.gdb'
sourcefc = arcpy.GetParameterAsText(0)
#filesdir = r'N:\Veg\Tools\NVIS_util\Uncertainty\ArcTools (review)\working'
filesdir = arcpy.GetParameterAsText(1) 

arcpy.env.workspace = filesdir
filesdirGDB = filesdir + "\\Working_SpMix.gdb"

#Outfilesdir = filesdir
Outfilesdir = arcpy.GetParameterAsText(2)
#Outfilesdir = r'N:\Veg\Tools\NVIS_util\Uncertainty\ArcTools (review)\working'

#create the working and output folders Working Output
try:
    arcpy.CreateFileGDB_management(filesdir, "\Working_SpMix.gdb")    
except:
    pass
try:
    arcpy.CreateFileGDB_management(Outfilesdir, "\Output_SpMix.gdb")
except:
    pass


#variables
          
Outputname3 = arcpy.GetParameterAsText(3)            #final output raster name
#cellsize = '100'
cellsize = arcpy.GetParameterAsText(4)              #output raster cell size 

#Uncertainity scores
#no_SPATIAL_MIX_defined = 4
no_SPATIAL_MIX_defined = arcpy.GetParameterAsText(5)
#PURE = 10
PURE = arcpy.GetParameterAsText(6)
#DOMINATE_mosaic = 5
DOMINATE_mosaic = arcpy.GetParameterAsText(7)
#MOSAIC = 4
MOSAIC = arcpy.GetParameterAsText(8)
#EQUAL_MOSAIC = 5
EQUAL_MOSAIC = arcpy.GetParameterAsText(9)
#INCOMPLETE = 4
INCOMPLETE = arcpy.GetParameterAsText(10)
#MOSAIC_UNKNOWN = 4
MOSAIC_UNKNOWN = arcpy.GetParameterAsText(11)
#UNKNOWN = 4
UNKNOWN = arcpy.GetParameterAsText(12)
#BLANK = 4
BLANK = no_SPATIAL_MIX_defined

NVIS4_1_KEY_DSET_EXT = arcpy.GetParameterAsText(13)
#NVIS4_1_KEY_DSET_EXT = r'N:\Veg\Tools\NVIS_util\Uncertainty\ArcTools (review)\working\Output1.gdb\Uncertianity_Age'

#fixed variables         
SpMix = 'SPATIAL_MIX'
input_ras_field = 'SPAT_MIX_No'
Outputname2 = "Beta_SpMix"   
Outputname3 = "Uncertainty_SpMix"         

#arcpy.env.overwriteOutput = 1

####################### functions ###########################################
   
############################################################################################
############### creates a list of feature class in GDB   #######################################
###########################################################################################

def listoffeatures(direct, filesdirGDB):
    arcpy.env.workspace = (direct)                      #list Features any direcotory
    lstFC = arcpy.ListFeatureClasses()
    featurelist = []    
    for foc in lstFC:
        featurelist.append(foc)         
    arcpy.env.workspace = (filesdirGDB)                    #change back to working file
    return featurelist

############################################################################################
############### tidy up   #######################################
###########################################################################################

#does a quick tidy up 
def tidyUp(feats, filesdirGDB): 
    arcpy.AddMessage ("\nCleaning up any working files in: " + filesdirGDB)                                                              
    for i in feats:      
        NeedToDelet = filesdirGDB + "\\" + i
        if arcpy.Exists(NeedToDelet):
            arcpy.Delete_management(NeedToDelet) 
            arcpy.AddMessage ("\n\tDeleted: " + "\\" + i + "_WORKING")
    else: print " "
    arcpy.AddMessage ("\n")   
    return
    
############################################################################################
############### copy and paste feature class for analysis   #######################################
###########################################################################################

def workingFeat(feats, sourcefc, filesdirGDB):
    arcpy.AddMessage("\nnew feature class:")
    print feats    
    for i in feats:
        arcpy.AddMessage("\ncreating feature: "+ i + "_WORKING")        
        featOut = sourcefc + "\\" + i     
        featin = filesdirGDB + "\\" + i
        try:                                        
            arcpy.CopyFeatures_management(featOut, featin)                                  
        except:
            pass

############################################################################################
#       Create new columns in the _WORKING feature classes
############################################################################################

def addcol(feats): 
    #variables to put into featrue class
    ColumnName = ['SPAT_MIX_No'] ;                                   #variables to put into featrue class    
    fieldType = ["FLOAT"];
    length = ["10"];
    
    #calc the iterations
    NoCol = len(ColumnName)                                                       #attribute column that denotes the regions, will be added if not an attribute 
    for fs in feats:
        count = 0
        while count < NoCol:
            print count                                                       
            try:
               arcpy.AddField_management(fs, ColumnName[count], fieldType[count], "", "", length[count]) 
               print ColumnName[count], fieldType[count], length[count]
            except: 
                print fs + " " +  ColumnName[count] + " field already exists"        
            count += 1 
   
##############################################################################
            #checking SPATIAL MIX
###############################################################################             
          
def CheckSpMix(row, SpMix, no_SPATIAL_MIX_defined, PURE, DOMINATE_mosaic, MOSAIC,EQUAL_MOSAIC, INCOMPLETE, MOSAIC_UNKNOWN,UNKNOWN,BLANK):           
    SM = row.getValue(SpMix)
    #arcpy.AddMessage  ("The SPATIAL MIX is: ")

    if SM == '': 
        arcpy.AddMessage ("no SPATIAL MIX defined")
        SPAT_MIX_No = (no_SPATIAL_MIX_defined)
        
    elif SM == ('pure'):
        arcpy.AddMessage ("PURE ") 
        SPAT_MIX_No = (PURE)
            
    elif SM == ('dominant mosaic'):
        arcpy.AddMessage ("DOMINATE mosaic ")
        SPAT_MIX_No = (DOMINATE_mosaic)
        
    elif SM == ('mosaic'):
        arcpy.AddMessage ("MOSAIC")
        SPAT_MIX_No = (MOSAIC)
                        
    elif SM == ('equal mosaic'):
        arcpy.AddMessage ("EQUAL MOSAIC")
        SPAT_MIX_No = (EQUAL_MOSAIC)
        
        
    elif SM == ('incomplete'):
        arcpy.AddMessage ("INCOMPLETE")
        SPAT_MIX_No = (INCOMPLETE)  
                                                                      
    elif SM == ('mosaic unknown'):
        arcpy.AddMessage ("MOSAIC UNKNOWN")
        SPAT_MIX_No = (MOSAIC_UNKNOWN)
            
    elif SM == ('unknown'):
        arcpy.AddMessage ("UNKNOWN") 
        SPAT_MIX_No = (UNKNOWN)      
    
    elif SM == ('Unknown'):
        arcpy.AddMessage ("UNKNOWN") 
        SPAT_MIX_No = (UNKNOWN)                                                          

    else: SPAT_MIX_No = (BLANK), arcpy.AddMessage ("no SPATIAL MIX defined")
    
    arcpy.AddMessage ('\n')  
    return SPAT_MIX_No

############################################################################################
############### creates a list of raster class in GDB   #######################################
###########################################################################################

def ListRasters(Outfilesdir):
    arcpy.env.workspace = (Outfilesdir + "\\Output_SpMix.gdb\\")
    lstFC = arcpy.ListRasters()
    rastlist = []    
    for foc in lstFC:
        rastlist.append(foc) 
    #del foc, lstFC        
    return rastlist

#add path ready for mosaicing
def MosaicRasters(Rasts):
    mosaics2 = []
    for no, rast in enumerate(Rasts): 
        print rast
        WORKING1 = Outfilesdir + "\\Output_SpMix.gdb\\" + Rasts[no]
        if no == 0:    
            mosaics2 = str(WORKING1)
        else:
            mosaics2 = str(mosaics2) + ';' + str(WORKING1)
    #del WORKING1
    return mosaics2

############################################################################################
###############   setting up               #######################################
###########################################################################################
arcpy.AddMessage ("\nList of features in .gdb: ")
feats = listoffeatures(sourcefc, filesdirGDB)            #list all feature in GBD - so know if _WORKING feature class
arcpy.AddMessage (feats)

#tidyUp(feats, filesdir)                       #deletes all _WORKING feature class already in directory

feats = listoffeatures(sourcefc, filesdirGDB)           #makes new list all feature in GBD - so can create new _WORKING feature class

workingFeat(feats, sourcefc, filesdirGDB)                 #creates new _WORKING feature class

featss = listoffeatures(filesdirGDB, filesdirGDB)           #makes new list all feature in GBD 

arcpy.AddMessage ("\nList of WORKING features: ")

try:
    addcol(feats)                        #adds the working columns in the _WORKING feature class
except:
    pass

#del(featss)                   

#loop through each feature class in .gdb and assign spatial mix uncertianity value f = feats[10]
for f in feats: 
  
    #output the feature class being analyised
    
    arcpy.AddMessage ("\n\n\n####################################")
    arcpy.AddMessage ("\tfeature class: " + str(f))
                  
    cur = arcpy.UpdateCursor(f)    
    for i,row in enumerate(cur):          
            #arcpy.AddMessage (str(i) + str(row)) 
            
            CheckingSpMix = CheckSpMix(row, SpMix, no_SPATIAL_MIX_defined, PURE, DOMINATE_mosaic, MOSAIC,EQUAL_MOSAIC, INCOMPLETE, MOSAIC_UNKNOWN,UNKNOWN,BLANK)                       
            fieldname = 'SPAT_MIX_No'            
            try:             
                row.setValue(fieldname, CheckingSpMix) 
            except: 
                row.setValue(fieldname, UNKNOWN)
            cur.updateRow(row)
  
    del(row, i, cur)       

##################################################################################
    #delete and copy new files over, then projects them
##################################################################################
    
    #reset extent
    arcpy.env.extent = None
    
    #temp files
    temp_fc0 = (filesdir + '\working_SpMix.gdb\output0')
    temp_fc1 = (filesdir + '\working_SpMix.gdb\output01')    
        
    # Process: Delete TEMP files
    for x in [temp_fc0, temp_fc1]:
        if arcpy.Exists(x):
            res = arcpy.Delete_management(x)
                
    res = arcpy.CopyFeatures_management(f, temp_fc0)                    #creates working output0
        
    # Process: Project - creates output01
    res = arcpy.Project_management(temp_fc0, temp_fc1, "PROJCS['GDA_1994_Australia_Albers',GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Albers'],PARAMETER['False_Easting',0.0],PARAMETER['False_Northing',0.0],PARAMETER['Central_Meridian',132.0],PARAMETER['Standard_Parallel_1',-18.0],PARAMETER['Standard_Parallel_2',-36.0],PARAMETER['Latitude_Of_Origin',0.0],UNIT['Meter',1.0]]", "", "GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")
    
###################################################################################
## Process: Feature to Raster
###################################################################################  
    ##defines extent of featrue class
    #arcpy.env.extent = r'F:\veg\Projects\other_veg_products\Uncertianity\Borders.gdb\state_borders_100k'    ###############
    arcpy.env.extent = NVIS4_1_KEY_DSET_EXT
    arcpy.env.snapRaster = NVIS4_1_KEY_DSET_EXT
    #converts to raster, into the working .GDB
    
    temp_ras_base = (filesdir + '\\tempras')
    try:
        arcpy.Delete_management (temp_ras_base)
    except: 
        pass

    
    res = arcpy.FeatureToRaster_conversion(temp_fc1, input_ras_field, temp_ras_base, cellsize)                 
    arcpy.AddMessage ('feature to raster complete: ' + f)        
    output_ras = (Outfilesdir + "\\Output_SpMix.gdb\\" + f[-(len(f)-8):])
    try:    
        res = arcpy.CopyRaster_management(temp_ras_base, output_ras, "", "", "", "NONE", "NONE", "")
    except:
        output_ras = (Outfilesdir + '\\' + f[-(len(f)-8):])
        res = arcpy.CopyRaster_management(temp_ras_base, output_ras, "", "", "", "NONE", "NONE", "")
    arcpy.AddMessage ("\nmoved output " + output_ras)    
    
    # Process: Build Pyramids And Statistics
    res = arcpy.BuildPyramidsandStatistics_management(temp_ras_base, "INCLUDE_SUBDIRECTORIES", "BUILD_PYRAMIDS", "CALCULATE_STATISTICS", "NONE")

##################################################################################
# mosaic all together
################################################################################## 
arcpy.AddMessage('Starting to rasterise')
Rasts = ListRasters(Outfilesdir)        #get list of rasters to mosaic
arcpy.AddMessage (Rasts)
Temp_Output = (Outfilesdir + "/")
##################################
    
mosaics = MosaicRasters(Rasts)                                                  #lists rasters to mosaic
   
arcpy.MosaicToNewRaster_management(mosaics, Temp_Output, Outputname2, "PROJCS['GDA_1994_Australia_Albers',GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Albers'],PARAMETER['False_Easting',0.0],PARAMETER['False_Northing',0.0],PARAMETER['Central_Meridian',132.0],PARAMETER['Standard_Parallel_1',-18.0],PARAMETER['Standard_Parallel_2',-36.0],PARAMETER['Latitude_Of_Origin',0.0],UNIT['Meter',1.0]]", "8_BIT_UNSIGNED", "", "1", "LAST", "FIRST")

temp_ras_base2 = Temp_Output + Outputname2                                      #makes raster outside the .gdb because ESRI causes errors if done within one
output_ras2 = Outfilesdir + "\\Output_SpMix.gdb\\" + Outputname3
arcpy.CopyRaster_management(temp_ras_base2, output_ras2, "", "", "", "NONE", "NONE", "")  
arcpy.BuildPyramidsandStatistics_management(output_ras2, "INCLUDE_SUBDIRECTORIES", "BUILD_PYRAMIDS", "CALCULATE_STATISTICS", "NONE")

#cleanup
#arcpy.Delete_management (temp_ras_base)
#arcpy.Delete_management (temp_ras_base2)

print "\n\n\t\t****************Finished**********************************"

