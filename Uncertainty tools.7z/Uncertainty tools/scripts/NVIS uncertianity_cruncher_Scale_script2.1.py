# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 16:18:44 2015

@author: a13690 (Jeremy Groves)

This suit of scripts have been developed in ERIN (Dept of the Environment) to create raster uncertainty layers that are intended to better describe the input datasets and assist in dynamic analyses of data quality and gaps in the NVIS extant theme dataset.
This specific script is to create the Scale Uncertainty raster layers. The inputs are
•	Layer: NVIS4_1_LUT_KEY_DSET10; 
•	LUT: NVIS4_1_LUT_KEY_DSET10
LUT Field: START_YEAR_ATTRIBUTE. This is the closest to when the data was collected, though does not necessarily reflect the collection date.
Found on the DotE NVIS website: https://www.environment.gov.au/land/native-vegetation/national-vegetation-information-system/data-products

"""

# Import arcpy module
import arcpy
import math

arcpy.CheckOutExtension('spatial')

#input variables  
sourcefc = arcpy.GetParameterAsText(0)                                   #input  feature class 

LUTtable = arcpy.GetParameterAsText(1)  
  
filesdir = arcpy.GetParameterAsText(2)                             #working folder (local drive)    

Outfilesdir = arcpy.GetParameterAsText(3)                           #where you want output raster files 

Outputname = arcpy.GetParameterAsText(4)                          #name of output raster file

#cellsize = '100'
cellsize = arcpy.GetParameterAsText(5)                             #cell size (100m NVIS standard)

####### raster variables
#catagory: lowest to highest
VLowCat = 10000001
LowCat = 1000001
MedCat = 100001
HighCat = 25001
VHighCat = 5001

#respective value for each catagory

VHigh = arcpy.GetParameterAsText(6)  
High = arcpy.GetParameterAsText(7)  
Med = arcpy.GetParameterAsText(8)   
Low = arcpy.GetParameterAsText(9)  
VLow = arcpy.GetParameterAsText(10)  
##############################################################################
#creating working and output .gdb, if it is already there it will skip 
try:
    arcpy.CreateFileGDB_management(filesdir, "\\Working_Scale.gdb")
except:
    pass
try:
    arcpy.CreateFileGDB_management(Outfilesdir, "\\Output_Scale.gdb")
except:
    pass

###########################################################################
#import LUT    
input_ras_field = 'Scale_cat'
#input_ras_field = gp.GetParameterAsText(5)                      #input LUT field that will be used to delineate the raster values

#join variables
input_fc_jf = 'DATA_SET_NUMBER'
input_lut_jf = 'DATA_SET_NUMBER'

#temp files
temp_fc0 = (filesdir + '\Working_Scale.gdb\output0')
temp_fc1 = (filesdir + '\Working_Scale.gdb\output01')

#set working paths
arcpy.env.workspace = sourcefc    
working_gdb = filesdir + 'Working_Scale.gdb'                                             

arcpy.env.overwriteOutput = 1

############################################################################################
############### rounding extent   #######################################
###########################################################################################	
def round_out(val, val_type, to):
    if val_type == 'max':
        return int(math.ceil(val/to)*to)
    elif val_type == 'min':
        return int((math.floor(val/to)*to))
    else:
        print "val type has to be either 'max' or 'min'"

############################################################################
############### calc RASTER value   #######################################
###########################################################################################	
def rastvalue(temp_fc1, input_ras_field, VLowCat, LowCat, MedCat, HighCat, VHighCat, VLow, Low, Med, High, VHigh):

    arcpy.AddField_management(temp_fc1, input_ras_field, "FLOAT", "5", "", "", "", "NULLABLE", "NON_REQUIRED", "")
        
    # classify depending on weights
    cur = arcpy.UpdateCursor(temp_fc1, '', '')        #SpatRef - updates the curser 
    #delineates the row values
    for row in cur:
        
        print "\n##############################" + str(row)
        if row.MAP_PUBLICATION_SCALE < VLowCat and row.MAP_PUBLICATION_SCALE > LowCat:
            row.Scale_cat = VHigh
        elif row.MAP_PUBLICATION_SCALE < LowCat and row.MAP_PUBLICATION_SCALE > MedCat:
            row.Scale_cat = High
        elif row.MAP_PUBLICATION_SCALE < MedCat and row.MAP_PUBLICATION_SCALE > HighCat:
            row.Scale_cat = Med
        elif row.MAP_PUBLICATION_SCALE < HighCat and row.MAP_PUBLICATION_SCALE > VHighCat:
            row.Scale_cat = Low    
        elif row.MAP_PUBLICATION_SCALE < VHighCat:
            row.Scale_cat = VLow     
        else:
            row.Scale_cat = 0
        cur.updateRow(row)
    del cur, row

##################################################################################
    #delete and copy new files over, then projects them
##################################################################################
 
arcpy.env.extent = None

# Process: Delete TEMP files
for x in [temp_fc0, temp_fc1]:
    if arcpy.Exists(x):
        res = arcpy.Delete_management(x)

res = arcpy.CopyFeatures_management(sourcefc, temp_fc0)

# Process: Project
res = arcpy.Project_management(temp_fc0, temp_fc1, "PROJCS['GDA_1994_Australia_Albers',GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Albers'],PARAMETER['False_Easting',0.0],PARAMETER['False_Northing',0.0],PARAMETER['Central_Meridian',132.0],PARAMETER['Standard_Parallel_1',-18.0],PARAMETER['Standard_Parallel_2',-36.0],PARAMETER['Latitude_Of_Origin',0.0],UNIT['Meter',1.0]]", "", "GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")

##################################################################################
#defines extent of featrue class
##################################################################################

# get new extent to the nearest 1000 m
desc = arcpy.Describe(temp_fc1)

print "\n----------------------\n"
print "Old Extent"
print "\t", desc.extent.YMax
print desc.extent.XMin, "\t\t", desc.extent.XMax
print "\t", desc.extent.YMin
print "\n----------------------\n"

n_xmax = round_out(desc.extent.XMax, 'max', 1000)
n_xmin = round_out(desc.extent.XMin, 'min', 1000)
n_ymax = round_out(desc.extent.YMax, 'max', 1000)
n_ymin = round_out(desc.extent.YMin, 'min', 1000)

print "New Extent"
print "\t", n_ymax
print n_xmin, "\t\t", n_xmax
print "\t", n_ymin
print "\n----------------------\n"

arcpy.env.extent = "%i %i %i %i" % (n_xmin, n_ymin, n_xmax, n_ymax)

##################################################################################
# Process: join table and catagorise output
##################################################################################    

# Process: Join Field
res = arcpy.JoinField_management(temp_fc1, input_fc_jf, LUTtable, input_lut_jf)

#calles the raster value function
rastvalue(temp_fc1, input_ras_field, VLowCat, LowCat, MedCat, HighCat, VHighCat, VLow, Low, Med, High, VHigh)

##################################################################################
# Process: Feature to Raster
##################################################################################  
  
#converts to raster, into the working .GDB
temp_ras_base = (filesdir + '\\tempRas')

res = arcpy.FeatureToRaster_conversion(temp_fc1, input_ras_field, temp_ras_base, cellsize)                 #variable for cell size
print 'feature to raster complete: ' + Outputname    

output_ras = (Outfilesdir + "\\Output_Scale.gdb\\" + Outputname)
try:    
    res = arcpy.CopyRaster_management(temp_ras_base, output_ras, "", "", "", "NONE", "NONE", "")
except:
    output_ras = (Outfilesdir + '\\' + Outputname)
    res = arcpy.CopyRaster_management(temp_ras_base, output_ras, "", "", "", "NONE", "NONE", "")
print "\nmoved output" + output_ras    

# Process: Build Pyramids And Statistics
res = arcpy.BuildPyramidsandStatistics_management(temp_ras_base, "INCLUDE_SUBDIRECTORIES", "BUILD_PYRAMIDS", "CALCULATE_STATISTICS", "NONE")

print "\n\n\t\t****************Finished**********************************"
    
