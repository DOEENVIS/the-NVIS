# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 16:18:44 2015

@author: a13690 (Jeremy Groves)

This suit of scripts have been developed in ERIN (Dept of the Environment) to create raster uncertainty layers that are intended to better describe the input datasets and assist in dynamic analyses of data quality and gaps in the NVIS extant theme dataset.
This specific script is to create the Origin Uncertainty raster layers. The inputs are
•	Layer: NVIS4_1_LUT_KEY_DSET10; 
•	LUT: NVIS4_1_LUT_KEY_DSET10
LUT Field: START_YEAR_ATTRIBUTE. This is the closest to when the data was collected, though does not necessarily reflect the collection date.
Found on the DotE NVIS website: https://www.environment.gov.au/land/native-vegetation/national-vegetation-information-system/data-products

"""


# Import arcpy module
import arcpy
import math

arcpy.CheckOutExtension('spatial')

#sourcefc = r'F:\veg\Projects\other_veg_products\Uncertianity\source.gdb\Keylayers'    
sourcefc = arcpy.GetParameterAsText(0)                                   #input  feature class 

#LUTtable = r'Database Connections\SPATPROD.sde\VEGETATION_SDE.NVIS4_1_LUT_KEY_DSET10'                             
LUTtable = arcpy.GetParameterAsText(1)

#filesdir = r'F:\veg\Projects\other_veg_products\Uncertianity\working'       
filesdir = arcpy.GetParameterAsText(2)                             #working folder     
    
#Outfilesdir = r'F:\veg\Projects\other_veg_products\Uncertianity\working'
Outfilesdir = arcpy.GetParameterAsText(3)                          #where you want output raster files 

Outputname = arcpy.GetParameterAsText(4)                         

#cellsize = '100'
cellsize = arcpy.GetParameterAsText(5)                             #cell size (100m NVIS standard)

####### raster variables

#respective value for each catagory

High = arcpy.GetParameterAsText(6)  
Med = arcpy.GetParameterAsText(7)  
Low = arcpy.GetParameterAsText(8)  

##############################################################################
#creating working and output .gdb, if it is already there it will skip
try:
    arcpy.CreateFileGDB_management(filesdir, "\Working_Origin.gdb")
except:
    pass
try:
    arcpy.CreateFileGDB_management(Outfilesdir, "\Output_Origin.gdb")
except:
    pass

###########################################################################

input_ras_field = 'Orign_cat'

#join variables
input_fc_jf = 'DATA_SET_NUMBER'
input_lut_jf = 'DATA_SET_NUMBER'

#temp files
temp_fc0 = (filesdir + '\Working_Origin.gdb\output0')
temp_fc1 = (filesdir + '\Working_Origin.gdb\output01')

#set working paths
arcpy.env.workspace = sourcefc    
working_gdb = filesdir + '\Working_Origin.gdb'                                             

arcpy.env.overwriteOutput = 1

############################################################################################
############### rounding extent   #######################################
###########################################################################################	
def round_out(val, val_type, to):
    if val_type == 'max':
        return int(math.ceil(val/to)*to)
    elif val_type == 'min':
        return int((math.floor(val/to)*to))
    else:
        print "val type has to be either 'max' or 'min'"

############################################################################
############### calc RASTER value   #######################################
###########################################################################################	
def rastvalue(temp_fc1, input_ras_field, Low, Med, High):

    arcpy.AddField_management(temp_fc1, input_ras_field, "FLOAT", "5", "", "", "", "NULLABLE", "NON_REQUIRED", "")
        
    # classify depending on weights
    cur = arcpy.UpdateCursor(temp_fc1, '', '')        #SpatRef - updates the curser 
    #delineates the row values
    for row in cur:
        if row.ATTRIBUTE_ORIGIN == 'GAP-FILL DATA':
            row.Orign_cat = High
        elif row.ATTRIBUTE_ORIGIN == 'OLDER_NVIS':
            row.Orign_cat = Med
        elif row.ATTRIBUTE_ORIGIN == 'STATE_TERR_NVIS':
            row.Orign_cat = Low    
        else:
            row.Orign_cat = 0
        cur.updateRow(row)
    del cur, row

##################################################################################
    #delete and copy new files over, then projects them
##################################################################################
 
arcpy.env.extent = None

# Process: Delete TEMP files
for x in [temp_fc0, temp_fc1]:
    if arcpy.Exists(x):
        res = arcpy.Delete_management(x)
        print res.getMessages()

res = arcpy.CopyFeatures_management(sourcefc, temp_fc0)

# Process: Project
res = arcpy.Project_management(temp_fc0, temp_fc1, "PROJCS['GDA_1994_Australia_Albers',GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Albers'],PARAMETER['False_Easting',0.0],PARAMETER['False_Northing',0.0],PARAMETER['Central_Meridian',132.0],PARAMETER['Standard_Parallel_1',-18.0],PARAMETER['Standard_Parallel_2',-36.0],PARAMETER['Latitude_Of_Origin',0.0],UNIT['Meter',1.0]]", "", "GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")

##################################################################################
#defines extent of featrue class
##################################################################################

# get new extent to the nearest 1000 m
desc = arcpy.Describe(temp_fc1)

print "\n----------------------\n"
print "Old Extent"
print "\t", desc.extent.YMax
print desc.extent.XMin, "\t\t", desc.extent.XMax
print "\t", desc.extent.YMin
print "\n----------------------\n"

n_xmax = round_out(desc.extent.XMax, 'max', 1000)
n_xmin = round_out(desc.extent.XMin, 'min', 1000)
n_ymax = round_out(desc.extent.YMax, 'max', 1000)
n_ymin = round_out(desc.extent.YMin, 'min', 1000)

print "New Extent"
print "\t", n_ymax
print n_xmin, "\t\t", n_xmax
print "\t", n_ymin
print "\n----------------------\n"

arcpy.env.extent = "%i %i %i %i" % (n_xmin, n_ymin, n_xmax, n_ymax)

##################################################################################
# Process: join table and catagorise output
##################################################################################    

# Process: Join Field
res = arcpy.JoinField_management(temp_fc1, input_fc_jf, LUTtable, input_lut_jf)

#calles the raster value function
rastvalue(temp_fc1, input_ras_field, Low, Med, High)

##################################################################################
# Process: Feature to Raster
##################################################################################  
  
#converts to raster, into the working .GDB
temp_ras_base = (filesdir + '\\tempRas')

res = arcpy.FeatureToRaster_conversion(temp_fc1, input_ras_field, temp_ras_base, cellsize)                 #variable for cell size
print 'feature to raster complete: ' + Outputname    

output_ras = (Outfilesdir + "\Output_Origin.gdb\\" + Outputname)
try:    
    res = arcpy.CopyRaster_management(temp_ras_base, output_ras, "", "", "", "NONE", "NONE", "")
except:
    output_ras = (Outfilesdir + '\\' + Outputname)
    res = arcpy.CopyRaster_management(temp_ras_base, output_ras, "", "", "", "NONE", "NONE", "")
print "\nmoved output" + output_ras    

# Process: Build Pyramids And Statistics
res = arcpy.BuildPyramidsandStatistics_management(temp_ras_base, "INCLUDE_SUBDIRECTORIES", "BUILD_PYRAMIDS", "CALCULATE_STATISTICS", "NONE")

print "\n\n\t\t****************Finished**********************************"
    
