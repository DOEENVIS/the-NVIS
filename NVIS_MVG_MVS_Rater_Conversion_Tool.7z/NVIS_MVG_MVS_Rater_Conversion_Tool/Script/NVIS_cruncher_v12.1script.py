# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 16:18:44 2015

@author: a13690 (Jeremy Groves)

script: takes all feature class and converts them to raster ready to be put together as the NVIS MVG or MVS layer. 
if you want to speed up the processing split the feature class in the geodatabase and runn on multi machines.
"""



# should put this one in diesel ----------------------------------------		
def round_out(val, val_type, to):
    if val_type == 'max':
        return int(math.ceil(val/to)*to)
    elif val_type == 'min':
        return int((math.floor(val/to)*to))
    else:
        print "val type has to be either 'max' or 'min'"
#----------------------------------------------------------------------

  

# Import arcpy module
import arcpy
import math

arcpy.CheckOutExtension('spatial')

#have final output space on N: so multi machines can work on it
#if output1 is already on N: make it create Output_2
#show count, where it is upto

#input variables
#filesdir = r'F:\veg\Projects\newVegProductsWorking\RasterOutput'       
filesdir = arcpy.GetParameterAsText(0)                             #working folder (local drive)    
   
#sourcefc = r'F:\veg\Projects\newVegProductsWorking\RasterOutput\source.gdb'    
sourcefc = arcpy.GetParameterAsText(1)                             #input  feature class    
   
#Outfilesdir = r'F:\veg\Projects\newVegProductsWorking\RasterOutput'
Outfilesdir = arcpy.GetParameterAsText(2)                          #where you want output raster files (N: maybe)

#cellsize = '100'
cellsize = arcpy.GetParameterAsText(3)                             #cell size (100m NVIS standard)

#LUTtable = r"Database Connections\SPATPROD.sde\VEGETATION_SDE.NVIS4_1_LUT_AUST_DETAIL4"
LUTtable = arcpy.GetParameterAsText(4)                             #LUT to join to feature class to get the MVG/MVS or other values

#input_ras_field = 'MVG_NUMBER'
input_ras_field = arcpy.GetParameterAsText(5)                      #input LUT field that will be used to delineate the raster values


#join variables
#input_fc_jf = 'NVISDSC1'
input_fc_jf = arcpy.GetParameterAsText(6)                          #value to join spatial data
#input_lut_jf = 'NVIS_ID'
input_lut_jf = arcpy.GetParameterAsText(7)                         #value to join LUT
##############################################################################
#creating working and output .gdb
try:
    arcpy.CreateFileGDB_management(filesdir, "\Working.gdb")
except:
    pass
try:
    arcpy.CreateFileGDB_management(Outfilesdir, "\Output.gdb")
except:
    pass

#temp files
temp_fc0 = (filesdir + '\working.gdb\output0')
temp_fc1 = (filesdir + '\working.gdb\output01')
#temp_ras_base = (filesdir + '\\ras')
#temp_table = (filesdir + '\working.gdb\tab1')

#set working paths
arcpy.env.workspace = sourcefc    
working_gdb = filesdir + '\working.gdb'                                             

arcpy.env.overwriteOutput = 1

############################################################################################
############### creates a list of feature class in GDB   #######################################
###########################################################################################

def listoffeatures():
    lstFC = arcpy.ListFeatureClasses()
    featurelist = []
    for foc in lstFC:
        featurelist.append(foc) 
        print foc
    return featurelist

feats = listoffeatures()

############################################################################################
############### calc extent   #######################################
###########################################################################################	
def round_out(val, val_type, to):
    if val_type == 'max':
        return int(math.ceil(val/to)*to)
    elif val_type == 'min':
        return int((math.floor(val/to)*to))
    else:
        print "val type has to be either 'max' or 'min'"
#----------------------------------------------------------------------

##################################################################################
    #delete and copy new files over, then projects them
##################################################################################

for f in feats:   
    arcpy.AddMessage  ('\ncurrently working on: ' + f)
    #reset extent
    arcpy.env.extent = None
    
    # Process: Delete TEMP files
    for x in [temp_fc0, temp_fc1]:
        if arcpy.Exists(x):
            res = arcpy.Delete_management(x)
            print res.getMessages()

    res = arcpy.CopyFeatures_management(f, temp_fc0)
    print res.getMessages()

    # Process: Project
    res = arcpy.Project_management(temp_fc0, temp_fc1, "PROJCS['GDA_1994_Australia_Albers',GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Albers'],PARAMETER['False_Easting',0.0],PARAMETER['False_Northing',0.0],PARAMETER['Central_Meridian',132.0],PARAMETER['Standard_Parallel_1',-18.0],PARAMETER['Standard_Parallel_2',-36.0],PARAMETER['Latitude_Of_Origin',0.0],UNIT['Meter',1.0]]", "", "GEOGCS['GCS_GDA_1994',DATUM['D_GDA_1994',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]")
    print res.getMessages()

##################################################################################
    #defines extent of featrue class
##################################################################################

    # get new extent to the nearest 1000 m
    desc = arcpy.Describe(temp_fc1)
    
    print "\n----------------------\n"
    print "Old Extent"
    print "\t", desc.extent.YMax
    print desc.extent.XMin, "\t\t", desc.extent.XMax
    print "\t", desc.extent.YMin
    print "\n----------------------\n"

    n_xmax = round_out(desc.extent.XMax, 'max', 1000)
    n_xmin = round_out(desc.extent.XMin, 'min', 1000)
    n_ymax = round_out(desc.extent.YMax, 'max', 1000)
    n_ymin = round_out(desc.extent.YMin, 'min', 1000)

    print "New Extent"
    print "\t", n_ymax
    print n_xmin, "\t\t", n_xmax
    print "\t", n_ymin
    print "\n----------------------\n"
    
    arcpy.env.extent = "%i %i %i %i" % (n_xmin, n_ymin, n_xmax, n_ymax)
    
##################################################################################
    # Process: Feature to Raster
##################################################################################    
    
    # Process: Join Field
    res = arcpy.JoinField_management(temp_fc1, input_fc_jf, LUTtable, input_lut_jf)
    print res.getMessages()
   
    
    
    #converts to raster, into the working .GDB
    temp_ras_base = (filesdir + '\working.gdb\\' + f)
    res = arcpy.FeatureToRaster_conversion(temp_fc1, input_ras_field, temp_ras_base, cellsize)                 #variable for cell size
    arcpy.AddMessage  ('feature to raster complete: ' + f )   
    print res.getMessages()
  
    # Process: Copy Raster (this could go to N: so multiple machnes can work on it)
    output_ras = (Outfilesdir + "\Output.gdb\\" + f)
    res = arcpy.CopyRaster_management(temp_ras_base, output_ras, "", "", "", "NONE", "NONE", "")
    arcpy.AddMessage ( "\nmoved output" + output_ras)
    print res.getMessages()

    # Process: Build Pyramids And Statistics
    res = arcpy.BuildPyramidsandStatistics_management(temp_ras_base, "INCLUDE_SUBDIRECTORIES", "BUILD_PYRAMIDS", "CALCULATE_STATISTICS", "NONE")
    print res.getMessages()
    arcpy.AddMessage ("#######################################################################")


arcpy.AddMessage ( "\n\n\t\t****************Finished**********************************")
#    diesel.cx_execute_nr(soe_team_conn, "UPDATE nvis_queue t SET t.status = 'Completed' WHERE t.objectid = %i" % (oid))
    # send Ian an email
    #send_email(['natalie.lyons@environment.gov.au'], "%s finished" % (input_fc), 'Completed')                   



#send_email(['natalie.lyons@environment.gov.au'], "NVIS Cruncher has finished", 'NVIS CRUNCHER HAS CRUNCHED')    
    
